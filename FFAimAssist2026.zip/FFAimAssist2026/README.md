# FF Aim Assist 2026
Companheiro para Free Fire: painel flutuante com seus perfis, treino de precisão e dicas.
Abra a pasta no Android Studio (Ladybug/Meerkat ou mais novo), aguarde o Gradle Sync e rode.
APK: Build > Build APK(s)  |  Terminal: ./gradlew assembleDebug
