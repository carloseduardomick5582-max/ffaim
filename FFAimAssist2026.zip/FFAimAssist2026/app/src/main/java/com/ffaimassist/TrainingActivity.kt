package com.ffaimassist

import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.ffaimassist.Ui.add

class TrainingActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val store = ProfileStore(this)
        val col = Ui.screen(this, "Treino de precisão", "30 segundos. Toque nos alvos antes que o anel feche. Treina reflexo e controle de dedo.")

        val stats = Ui.text(this, "Pronto para começar", 15f, Ui.BLUE, true)
        col.add(stats, 14)

        val view = TargetView(this)
        col.addView(view, LinearLayout.LayoutParams(-1, Ui.dp(this, 420)).apply { topMargin = Ui.dp(this@TrainingActivity, 12) })

        view.onTick = { h, m, avg, s -> stats.text = "Acertos $h  ·  Erros $m  ·  Média ${avg} ms  ·  ${s}s" }
        view.onEnd = { h, m, avg ->
            val acc = if (h + m == 0) 0 else h * 100 / (h + m)
            val rec = h > store.bestHits
            if (rec) store.bestHits = h
            stats.text = "Fim! $h acertos · precisão $acc% · ${avg} ms" + if (rec) "  🏆 recorde" else ""
        }
        col.add(Ui.button(this, "INICIAR TREINO", Ui.RED) { view.start() }, 14)
    }
}
