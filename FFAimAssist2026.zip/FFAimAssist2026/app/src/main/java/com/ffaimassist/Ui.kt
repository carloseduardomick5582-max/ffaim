package com.ffaimassist

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.content.res.ColorStateList
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Helpers do tema gamer: preto + vermelho + azul. */
object Ui {
    val BG = 0xFF07070C.toInt()
    val CARD = 0xFF13131B.toInt()
    val RED = 0xFFFF2D3F.toInt()
    val BLUE = 0xFF2D8CFF.toInt()
    val TEXT = 0xFFEDEDF2.toInt()
    val MUTED = 0xFF8A8A99.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun bg(c: Context, fill: Int, stroke: Int = 0x33FFFFFF, radius: Int = 16, oval: Boolean = false) =
        GradientDrawable().apply {
            shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
            setColor(fill); cornerRadius = dp(c, radius).toFloat(); setStroke(dp(c, 1), stroke)
        }

    fun text(c: Context, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) =
        TextView(c).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun LinearLayout.add(v: View, top: Int = 0): View {
        addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(context, top) })
        return v
    }

    fun card(c: Context, accent: Int = 0x33FFFFFF) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(c, CARD, accent)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
    }

    fun button(c: Context, label: String, color: Int = RED, onClick: () -> Unit) =
        TextView(c).apply {
            text = label; textSize = 15f; setTextColor(TEXT); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(c, 16), dp(c, 13), dp(c, 16), dp(c, 13))
            background = bg(c, (color and 0x00FFFFFF) or 0x33000000, color)
            setOnClickListener { onClick() }
            setOnTouchListener { v, e ->  // animação suave de toque
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(.96f).scaleY(.96f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }

    /** Tela base: fundo preto, título com barra vermelha, tratamento de insets (Android 15/16 edge-to-edge). */
    fun screen(a: Activity, title: String, subtitle: String? = null): LinearLayout {
        val sv = ScrollView(a).apply { setBackgroundColor(BG); isFillViewport = true }
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            val p = dp(a, 18); setPadding(p, p, p, p)
        }
        sv.addView(col)
        ViewCompat.setOnApplyWindowInsetsListener(sv) { v, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom); ins
        }
        a.setContentView(sv)
        val bar = View(a).apply { background = bg(a, RED, RED, 3) }
        col.addView(bar, LinearLayout.LayoutParams(dp(a, 44), dp(a, 4)))
        col.add(text(a, title, 26f, TEXT, true), 10)
        if (subtitle != null) col.add(text(a, subtitle, 13f, MUTED), 2)
        col.alpha = 0f; col.animate().alpha(1f).setDuration(350).start()
        return col
    }

    /** Linha com SeekBar: label + valor + slider. */
    fun sliderRow(c: Context, label: String, value: Int, lo: Int, hi: Int, accent: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val tv = text(c, label, 14f)
        val vv = text(c, value.toString(), 14f, accent, true)
        head.addView(tv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)); head.addView(vv)
        val sb = SeekBar(c).apply {
            max = hi - lo; progress = value - lo
            progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    vv.text = (p + lo).toString(); if (u) onChange(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(head); box.addView(sb)
        box.setPadding(0, dp(c, 4), 0, dp(c, 4))
        return box
    }
}
