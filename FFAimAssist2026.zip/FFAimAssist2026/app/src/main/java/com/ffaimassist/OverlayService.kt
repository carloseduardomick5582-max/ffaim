package com.ffaimassist

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/**
 * Painel flutuante. Janela do tamanho do conteúdo (wrap_content) + FLAG_NOT_FOCUSABLE,
 * então os toques fora dela vão direto para o jogo. Só mostra anotações do perfil ativo.
 */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false
        const val CH = "ffaa_overlay"
        const val STOP = "com.ffaimassist.STOP"
    }

    private lateinit var wm: WindowManager
    private lateinit var store: ProfileStore
    private var root: LinearLayout? = null
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        startFg()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (root == null) build()
        running = true
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Painel flutuante", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction(STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_logo).setContentTitle("FF Aim Assist 2026")
            .setContentText("Painel flutuante ativo").setContentIntent(open).setOngoing(true)
            .addAction(0, "Desligar", stop).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    private fun build() {
        store = ProfileStore(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val slop = ViewConfiguration.get(this).scaledTouchSlop

        bubble = TextView(this).apply {
            text = "FF"; gravity = Gravity.CENTER; setTextColor(Ui.TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = Ui.bg(this@OverlayService, 0xEE0A0A12.toInt(), Ui.RED, 40, true)
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = Ui.bg(this@OverlayService, 0xF0101018.toInt(), Ui.BLUE, 14)
            val p = Ui.dp(this@OverlayService, 10); setPadding(p, p, p, p)
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble); addView(panel, LinearLayout.LayoutParams(Ui.dp(this@OverlayService, 190), -2).apply {
                topMargin = Ui.dp(this@OverlayService, 6)
            })
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = Ui.dp(this@OverlayService, 160) }

        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val ox = (e.rawX - dx).toInt(); val oy = (e.rawY - dy).toInt()
                    if (abs(ox) > slop || abs(oy) > slop) moved = true
                    if (moved) { lp.x = sx + ox; lp.y = sy + oy; wm.updateViewLayout(root, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggle(); true }
                else -> false
            }
        }
        applyLook()
        wm.addView(root, lp)
    }

    private fun applyLook() {
        val p = store.current(); val rank = store.rankMode
        val size = Ui.dp(this, if (rank) 36 else p.bubbleSize)
        bubble.layoutParams = LinearLayout.LayoutParams(size, size)
        bubble.textSize = if (rank) 11f else 14f
        val a = p.overlayOpacity / 100f
        root?.alpha = if (rank) minOf(a, 0.65f) else a
    }

    private fun toggle() {
        if (panel.visibility == View.VISIBLE) hidePanel() else {
            refreshPanel()
            panel.visibility = View.VISIBLE
            if (!store.rankMode) { panel.alpha = 0f; panel.animate().alpha(1f).setDuration(180).start() }
        }
    }

    private fun hidePanel() {
        if (store.rankMode) panel.visibility = View.GONE
        else panel.animate().alpha(0f).setDuration(150).withEndAction { panel.visibility = View.GONE }.start()
    }

    private fun refreshPanel() {
        applyLook()
        val p = store.current(); val rank = store.rankMode
        panel.removeAllViews()
        panel.addView(Ui.text(this, p.name.uppercase(), 13f, Ui.RED, true))
        if (rank) {
            panel.addView(Ui.text(this, "G${p.general} RD${p.redDot} 2x${p.scope2x} 4x${p.scope4x} AWM${p.awm} FL${p.freeLook}", 11f))
        } else {
            val rows = listOf("Geral" to p.general, "Red Dot" to p.redDot, "Mira 2x" to p.scope2x,
                "Mira 4x" to p.scope4x, "AWM" to p.awm, "Olhar livre" to p.freeLook)
            rows.forEach { (n, v) ->
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                r.addView(Ui.text(this, n, 12f, Ui.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(Ui.text(this, v.toString(), 12f, Ui.BLUE, true))
                panel.addView(r)
            }
            if (p.note.isNotBlank()) panel.addView(Ui.text(this, p.note, 11f, Ui.TEXT).apply { setPadding(0, Ui.dp(this@OverlayService, 6), 0, 0) })
        }
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, Ui.dp(this@OverlayService, 8), 0, 0) }
        fun b(t: String, c: Int, act: () -> Unit) = TextView(this).apply {
            text = t; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Ui.TEXT)
            setPadding(0, Ui.dp(this@OverlayService, 7), 0, Ui.dp(this@OverlayService, 7))
            background = Ui.bg(this@OverlayService, 0x22000000, c, 8); setOnClickListener { act() }
        }.also { btns.addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 }) }
        b("Perfil ▶", Ui.BLUE) { store.active = (store.active + 1) % store.all().size; refreshPanel() }
        b("Minimizar", Ui.MUTED) { hidePanel() }
        b("Sair", Ui.RED) { stopSelf() }
        panel.addView(btns)
    }

    override fun onDestroy() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null; running = false
        super.onDestroy()
    }
}
