package com.ffaimassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.random.Random

/** Mini-jogo de reflexo/precisão, 30 s. Roda só dentro do app, sem relação com o Free Fire. */
class TargetView(c: Context) : View(c) {
    var onTick: ((hits: Int, miss: Int, avgMs: Long, secLeft: Int) -> Unit)? = null
    var onEnd: ((hits: Int, miss: Int, avgMs: Long) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val r = 32 * d
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val life = 1400L
    private val total = 30_000L
    private var running = false
    private var t0 = 0L; private var spawnT = 0L
    private var x = 0f; private var y = 0f
    private var hits = 0; private var miss = 0; private var rtSum = 0L

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.uptimeMillis()
            if (now - t0 >= total) { running = false; onEnd?.invoke(hits, miss, avg()); invalidate(); return }
            if (now - spawnT >= life) { miss++; spawn() }
            onTick?.invoke(hits, miss, avg(), ((total - (now - t0)) / 1000).toInt() + 1)
            invalidate(); postOnAnimation(this)
        }
    }

    private fun avg() = if (hits == 0) 0L else rtSum / hits

    private fun spawn() {
        val w = width.toFloat(); val h = height.toFloat()
        x = r + Random.nextFloat() * (w - 2 * r).coerceAtLeast(1f)
        y = r + Random.nextFloat() * (h - 2 * r).coerceAtLeast(1f)
        spawnT = SystemClock.uptimeMillis()
    }

    fun start() {
        hits = 0; miss = 0; rtSum = 0; running = true
        t0 = SystemClock.uptimeMillis(); spawn(); postOnAnimation(loop)
    }

    override fun onDraw(cv: Canvas) {
        paint.style = Paint.Style.FILL; paint.color = 0xFF0E0E16.toInt()
        cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 24 * d, 24 * d, paint)
        if (!running) return
        val prog = ((SystemClock.uptimeMillis() - spawnT) / life.toFloat()).coerceIn(0f, 1f)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3 * d; paint.color = Ui.BLUE
        cv.drawCircle(x, y, r * (1f + (1f - prog) * 1.2f), paint)          // anel que encolhe
        paint.style = Paint.Style.FILL; paint.color = Ui.RED; cv.drawCircle(x, y, r, paint)
        paint.color = 0xFFFFFFFF.toInt(); cv.drawCircle(x, y, r * 0.35f, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN && running) {
            if (hypot(e.x - x, e.y - y) <= r * 1.15f) {
                hits++; rtSum += SystemClock.uptimeMillis() - spawnT; spawn()
            } else miss++
            invalidate()
        }
        return true
    }
}
