package com.ffaimassist

import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.ffaimassist.Ui.add

class ProfilesActivity : AppCompatActivity() {

    private lateinit var store: ProfileStore
    private lateinit var list: MutableList<Profile>
    private var idx = 0

    // Pontos de partida (geral, red dot, 2x, 4x, AWM, olhar livre). Ajuste de 5 em 5 no treino.
    private val presets = listOf(
        "Equilibrado" to intArrayOf(90, 85, 80, 75, 50, 70),
        "Rush" to intArrayOf(100, 95, 85, 70, 45, 80),
        "Precisão" to intArrayOf(80, 75, 70, 65, 40, 60)
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = ProfileStore(this); list = store.all()
        idx = store.active.coerceIn(0, list.size - 1)
        render()
    }

    override fun onPause() { super.onPause(); store.save(list); store.active = idx }

    private fun render() {
        val p = list[idx]
        val col = Ui.screen(this, "Perfis & Sensibilidade",
            "O Free Fire não permite alterar a sensibilidade de fora. Anote aqui os valores que você usa e confira no painel flutuante.")

        // chips de perfis
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        list.forEachIndexed { i, pr ->
            val sel = i == idx
            row.addView(Ui.button(this, pr.name, if (sel) Ui.RED else Ui.BLUE) { idx = i; render() },
                LinearLayout.LayoutParams(-2, -2).apply { marginEnd = Ui.dp(this@ProfilesActivity, 8) })
        }
        col.add(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }, 16)

        // nome e nota
        val c1 = Ui.card(this, Ui.BLUE)
        fun edit(hint: String, v: String, multi: Boolean) = EditText(this).apply {
            setText(v); this.hint = hint; setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED); textSize = 14f
            if (multi) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        c1.add(edit("Nome do perfil", p.name, false).apply { doAfterTextChanged { p.name = it.toString() } })
        c1.add(edit("Anotação (aparece no painel)", p.note, true).apply { doAfterTextChanged { p.note = it.toString() } }, 4)
        col.add(c1, 12)

        // sensibilidades
        val c2 = Ui.card(this, Ui.RED)
        c2.addView(Ui.text(this, "Sensibilidade (0–100)", 16f, Ui.TEXT, true))
        c2.add(Ui.sliderRow(this, "Geral", p.general, 0, 100, Ui.RED) { p.general = it })
        c2.add(Ui.sliderRow(this, "Red Dot", p.redDot, 0, 100, Ui.RED) { p.redDot = it })
        c2.add(Ui.sliderRow(this, "Mira 2x", p.scope2x, 0, 100, Ui.RED) { p.scope2x = it })
        c2.add(Ui.sliderRow(this, "Mira 4x", p.scope4x, 0, 100, Ui.RED) { p.scope4x = it })
        c2.add(Ui.sliderRow(this, "AWM", p.awm, 0, 100, Ui.RED) { p.awm = it })
        c2.add(Ui.sliderRow(this, "Olhar livre", p.freeLook, 0, 100, Ui.RED) { p.freeLook = it })
        col.add(c2, 12)

        // HUD do painel
        val c3 = Ui.card(this, Ui.BLUE)
        c3.addView(Ui.text(this, "HUD do painel flutuante", 16f, Ui.TEXT, true))
        c3.add(Ui.sliderRow(this, "Opacidade (%)", p.overlayOpacity, 30, 100, Ui.BLUE) { p.overlayOpacity = it })
        c3.add(Ui.sliderRow(this, "Tamanho da bolha (dp)", p.bubbleSize, 36, 72, Ui.BLUE) { p.bubbleSize = it })
        col.add(c3, 12)

        // presets
        col.add(Ui.text(this, "Pontos de partida", 14f, Ui.MUTED, true), 16)
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEach { (n, v) ->
            pr.addView(Ui.button(this, n, Ui.BLUE) {
                p.general = v[0]; p.redDot = v[1]; p.scope2x = v[2]; p.scope4x = v[3]; p.awm = v[4]; p.freeLook = v[5]; render()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = Ui.dp(this@ProfilesActivity, 6) })
        }
        col.add(pr, 6)

        // ações
        col.add(Ui.button(this, "NOVO PERFIL (cópia deste)", Ui.BLUE) {
            list.add(p.copy(name = "Perfil ${list.size + 1}")); idx = list.size - 1; render()
        }, 16)
        col.add(Ui.button(this, "EXCLUIR PERFIL", Ui.RED) {
            if (list.size > 1) { list.removeAt(idx); idx = idx.coerceAtMost(list.size - 1); render() }
        }, 10)
        col.add(Ui.button(this, "SALVAR E USAR ESTE PERFIL", Ui.RED) {
            store.save(list); store.active = idx; finish()
        }, 10)
    }
}
