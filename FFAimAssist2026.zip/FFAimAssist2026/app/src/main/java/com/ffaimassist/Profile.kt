package com.ffaimassist

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Perfil de referência: valores que o jogador digita manualmente nas opções do Free Fire. */
data class Profile(
    var name: String,
    var general: Int = 90,
    var redDot: Int = 85,
    var scope2x: Int = 80,
    var scope4x: Int = 75,
    var awm: Int = 50,
    var freeLook: Int = 70,
    var overlayOpacity: Int = 85,   // 30..100
    var bubbleSize: Int = 48,       // 36..72 dp
    var note: String = ""
) {
    fun toJson() = JSONObject().put("n", name).put("g", general).put("r", redDot)
        .put("s2", scope2x).put("s4", scope4x).put("a", awm).put("f", freeLook)
        .put("o", overlayOpacity).put("b", bubbleSize).put("t", note)

    companion object {
        fun from(j: JSONObject) = Profile(
            j.optString("n", "Perfil"), j.optInt("g", 90), j.optInt("r", 85),
            j.optInt("s2", 80), j.optInt("s4", 75), j.optInt("a", 50), j.optInt("f", 70),
            j.optInt("o", 85), j.optInt("b", 48), j.optString("t", "")
        )
    }
}

class ProfileStore(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("ffaa", Context.MODE_PRIVATE)

    fun all(): MutableList<Profile> {
        val s = sp.getString("profiles", null) ?: return defaults()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { Profile.from(a.getJSONObject(it)) }.ifEmpty { defaults() }
        } catch (e: Exception) { defaults() }
    }

    fun save(list: List<Profile>) =
        sp.edit().putString("profiles", JSONArray(list.map { it.toJson() }).toString()).apply()

    var active: Int
        get() = sp.getInt("active", 0)
        set(v) { sp.edit().putInt("active", v).apply() }

    var rankMode: Boolean
        get() = sp.getBoolean("rank", false)
        set(v) { sp.edit().putBoolean("rank", v).apply() }

    var bestHits: Int
        get() = sp.getInt("best", 0)
        set(v) { sp.edit().putInt("best", v).apply() }

    fun current(): Profile {
        val l = all()
        return l[active.coerceIn(0, l.size - 1)]
    }

    private fun defaults() = mutableListOf(
        Profile("Equilibrado"),
        Profile("Rush", 100, 95, 85, 70, 45, 80, note = "Curta distância: mire em movimento, rajadas curtas."),
        Profile("Precisão", 80, 75, 70, 65, 40, 60, note = "Longa distância: pare, mire, atire.")
    )
}
