package com.ffaimassist

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.Switch
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.ffaimassist.Ui.add

class MainActivity : AppCompatActivity() {

    private lateinit var store: ProfileStore

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startOverlay() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
    }

    override fun onResume() { super.onResume(); build() }

    private fun build() {
        val col = Ui.screen(this, "FF AIM ASSIST 2026", "Painel de treino, perfis e anotações para Free Fire")

        // --- Status ---
        val hasPerm = Settings.canDrawOverlays(this)
        val running = OverlayService.running
        val st = Ui.card(this, if (hasPerm) Ui.BLUE else Ui.RED)
        st.addView(Ui.text(this, if (hasPerm) "● Permissão de sobreposição concedida" else "● Permissão de sobreposição necessária",
            14f, if (hasPerm) Ui.BLUE else Ui.RED, true))
        st.add(Ui.text(this, "Perfil ativo: ${store.current().name}" + if (store.rankMode) "  ·  Modo Rank" else "", 13f, Ui.MUTED), 4)
        col.add(st, 18)

        // --- Ação principal ---
        if (!hasPerm) {
            col.add(Ui.button(this, "CONCEDER PERMISSÃO DE SOBREPOSIÇÃO", Ui.RED) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }, 12)
        } else if (running) {
            col.add(Ui.button(this, "DESLIGAR PAINEL FLUTUANTE", Ui.RED) {
                stopService(Intent(this, OverlayService::class.java)); window.decorView.postDelayed({ build() }, 200)
            }, 12)
        } else {
            col.add(Ui.button(this, "LIGAR PAINEL FLUTUANTE", Ui.BLUE) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) else startOverlay()
            }, 12)
        }

        // --- Modo Rank ---
        val rank = Ui.card(this, Ui.RED)
        rank.addView(Ui.text(this, "Modo Rank", 17f, Ui.TEXT, true))
        rank.add(Ui.text(this, "Bolha menor e translúcida, painel compacto, sem animações e sem nenhum processamento em segundo plano — economiza bateria e deixa a tela limpa.", 12f, Ui.MUTED), 4)
        val sw = Switch(this).apply {
            text = "Ativar Modo Rank"; setTextColor(Ui.TEXT); isChecked = store.rankMode
            setOnCheckedChangeListener { _, c -> store.rankMode = c }
        }
        rank.add(sw, 8)
        col.add(rank, 14)

        // --- Navegação ---
        col.add(Ui.button(this, "PERFIS & SENSIBILIDADE", Ui.BLUE) { startActivity(Intent(this, ProfilesActivity::class.java)) }, 14)
        col.add(Ui.button(this, "TREINO DE PRECISÃO  (melhor: ${store.bestHits} acertos)", Ui.RED) { startActivity(Intent(this, TrainingActivity::class.java)) }, 10)
        col.add(Ui.button(this, "DICAS DE MIRA E MOVIMENTAÇÃO", Ui.BLUE) { startActivity(Intent(this, TipsActivity::class.java)) }, 10)

        col.add(Ui.text(this, "Este app não toca no Free Fire: não lê, não modifica, não injeta código e não automatiza toques. Ele só exibe suas próprias anotações por cima da tela e oferece treino separado.", 11f, Ui.MUTED), 20)
    }

    private fun startOverlay() {
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        window.decorView.postDelayed({ build() }, 300)
    }
}
