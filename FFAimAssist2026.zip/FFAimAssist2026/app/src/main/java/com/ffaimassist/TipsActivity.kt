package com.ffaimassist

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ffaimassist.Ui.add

class TipsActivity : AppCompatActivity() {
    private val tips = listOf(
        "Mire na altura da cabeça" to "Mantenha a mira alinhada com a altura da cabeça enquanto anda. Ajustar só um pouco na hora do tiro é mais rápido que subir a mira do chão.",
        "Mude uma coisa por vez" to "Altere a sensibilidade de 5 em 5 e teste no treino do jogo por alguns minutos. Mudar tudo junto impede de saber o que ajudou.",
        "Sensibilidade menor = controle" to "Valores muito altos fazem a mira passar do alvo. Se você 'estoura' a cabeça e erra por cima, tente reduzir.",
        "Rajadas curtas" to "Em médio e longo alcance, rajadas curtas mantêm a mira estável. Segurar o gatilho aumenta o recuo.",
        "Pare para atirar de longe" to "Em longa distância, pare, mire e atire. Em curta, movimente-se de lado (strafe) alternando direções para ser difícil de acertar.",
        "Use coberturas" to "Peek rápido: apareça, atire e volte. Evita trocar tiros em campo aberto.",
        "Layout de botões" to "Posicione o botão de tiro onde o polegar chega sem sair do lugar. Layouts de 3 ou 4 dedos dão mira e movimento ao mesmo tempo.",
        "Treine todo dia, pouco tempo" to "10 minutos de treino por dia rendem mais que uma hora semanal. Use o treino do app e a sala de treino do jogo.",
        "Desempenho do aparelho" to "Feche apps em segundo plano, ative modo jogo e mantenha o celular fresco. Queda de FPS atrapalha mais a mira que qualquer configuração."
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = Ui.screen(this, "Dicas de mira e movimentação", "Fundamentos que melhoram a consistência")
        tips.forEachIndexed { i, (t, d) ->
            val c = Ui.card(this, if (i % 2 == 0) Ui.RED else Ui.BLUE)
            c.addView(Ui.text(this, t, 16f, Ui.TEXT, true))
            c.add(Ui.text(this, d, 13f, Ui.MUTED), 4)
            col.add(c, 12)
        }
    }
}
